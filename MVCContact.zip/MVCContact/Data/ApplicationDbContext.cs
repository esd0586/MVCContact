﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MVCContact.Models;

namespace MVCContact.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<MVCContact.Models.Contact> Contact { get; set; } = default!;
        public DbSet<MVCContact.Models.Categorie> Categorie { get; set; } = default!;
    }
}
