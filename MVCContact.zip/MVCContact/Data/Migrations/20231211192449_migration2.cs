﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MVCContact.Data.Migrations
{
    /// <inheritdoc />
    public partial class migration2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categorie",
                columns: table => new
                {
                    CategorieId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nom = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categorie", x => x.CategorieId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contact_CategorieID",
                table: "Contact",
                column: "CategorieID");

            migrationBuilder.AddForeignKey(
                name: "FK_Contact_Categorie_CategorieID",
                table: "Contact",
                column: "CategorieID",
                principalTable: "Categorie",
                principalColumn: "CategorieId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contact_Categorie_CategorieID",
                table: "Contact");

            migrationBuilder.DropTable(
                name: "Categorie");

            migrationBuilder.DropIndex(
                name: "IX_Contact_CategorieID",
                table: "Contact");
        }
    }
}
