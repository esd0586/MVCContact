﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using MVCContact.Data;
using MVCContact.Models;

namespace MVCContact.Components
{
    //Creer le MenuWidget View Component
    public class MenuWidget : ViewComponent
    {
        //1.Database Context
        private readonly ApplicationDbContext _context;

        //2. Constructeur: Initialiser la connection a la base de donnees
        public MenuWidget(ApplicationDbContext context)
        {
            _context = context;
        }

        //3. Creer la methode InvokeAsync
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var items = await GetCategorieAsync();
            return View(items);
        }

        private Task<List<Categorie>> GetCategorieAsync()
        {
            return _context.Categorie.ToListAsync();
        }
    }
}
