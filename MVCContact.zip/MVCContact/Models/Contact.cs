﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace MVCContact.Models
{
    public class Contact
    {
        public int ContactId { get; set; }  //Primary Key

        [Required]
        [MaxLength(64)]
        public string Prenom {  get; set; }

        [Required]
        [MaxLength(64)]
        public string Nom { get; set; }

        public string? Adresse { get; set; }

        public string? Ville { get; set; }

        public string? Province { get; set; }

        [Display(Name = "Code Postal")]
        [DataType(DataType.PostalCode)]
        public string? CodePostal { get; set; }
        
        [DataType(DataType.PhoneNumber)]
        public string? Telephone { get; set; }

        [DataType(DataType.EmailAddress)]
        public string? Courriel { get; set;}

        [DataType(DataType.DateTime)]
        [Display(Name = "Date de creation")]
        public DateTime? DateCreation { get; set; }

        public int CategorieID { get; set; }        //Foreign Key

        public string UserName { get; set; }
    }
}