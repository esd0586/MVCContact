﻿using System.ComponentModel.DataAnnotations;

namespace MVCContact.Models
{
    public class Categorie
    {
        public int CategorieId { get; set; }
        [Required]
        public string? Nom { get; set; }

        public virtual ICollection<Contact>? Contacts { get; set; }
    }
}
